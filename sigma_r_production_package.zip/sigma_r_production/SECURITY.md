# Security Policy
Report vulnerabilities privately to the repository owner. Do not include live credentials, personal data, or production exploit material in public issues. Rotate `SIGMA_R_RECEIPT_KEY` through the deployment secret manager. Run behind authentication, TLS, least privilege, network policy, resource limits, and an independent authorization service.
