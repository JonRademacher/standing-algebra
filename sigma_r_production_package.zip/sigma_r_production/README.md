# Sigma-R Firewall Production Package

Provider-neutral middleware for enforcing the operational separation:

`AI proposal -> evidence/authority checks -> admissibility envelope -> projection or non-realization -> signed receipt`

## Attribution
Based on **Standing Algebra (Sigma-R)** by **Jonathan Rademacher**. Reference DOI: `10.5281/zenodo.23016270`.

## Install
```bash
pip install .
# development
pip install -e ".[dev]"
```

## Verify
```bash
python -m sigma_r.cli self-test
pytest
python -m compileall src
```

## Minimal integration
```python
from sigma_r import SigmaRFirewall
fw=SigmaRFirewall()
r=fw.guard_text(model_output, {"sources":["retrieval-id"],"user_authorized":True}, {"grounding_score":.98,"consequential_action":False})
if not r.allowed:
    raise RuntimeError(r.to_dict())
return r.output_text
```

## Production requirements
The default `MetadataEvaluator` is intentionally conservative and is not a substitute for independent evaluation. Connect evaluators for retrieval support, action authorization, deployment risk, tests, rollback readiness, sensitive-data handling, and domain policy. Place Sigma-R immediately before the consequential action boundary, not only around the model text endpoint.

Use `SIGMA_R_RECEIPT_KEY` to HMAC-sign receipt records. Never put the key in policy JSON. Forward JSONL audit output to an append-only store or SIEM.

## Decisions
`ALLOW`, `PROJECT`, `ABSTAIN`, `ADAPTER_FAIL`, `EVIDENCE_BLOCK`, `AUTHORITY_BLOCK`, `DOMINATION_BLOCK`, `POLICY_BLOCK`, `EMERGENCY_G`, `EVALUATOR_FAIL`, `CIRCUIT_OPEN`, `RATE_LIMIT`.

## Honest status
This package is internally executable and testable. It is not yet independently security audited, externally benchmarked, formally verified, or certified. Production readiness therefore means production-oriented engineering plus explicit residuals, not a claim that deployment risk has been eliminated.
