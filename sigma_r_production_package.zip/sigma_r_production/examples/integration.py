from sigma_r import SigmaRFirewall, CallableAdapter

def model(prompt): return {"choices":[{"message":{"content":"Grounded answer"}}]}
fw=SigmaRFirewall()
guarded=CallableAdapter(fw,model)
r=guarded("hello",context={"sources":["doc-1"]},metadata={"grounding_score":1.0})
print(r.to_dict())
