# Threat Model

## Protected assets
Production systems, authorization integrity, evidence provenance, policy integrity, receipt continuity, and the non-execution boundary.

## Principal threats
1. Prompt or payload text attempting to mark itself as evidence or authority.
2. Adapter omission that hides risk-bearing structure.
3. Repair logic that mutates evidence, authority, protection, or policy state.
4. Policy downgrade, threshold drift, or unrecorded version change.
5. Receipt truncation, reordering, replay, or substitution.
6. Integrator treating `ALLOW` as execution authority.
7. Parser ambiguity, resource exhaustion, and oversized artifacts.

## Controls
Typed fields; ordered fail-closed gates; input-size limits; canonical serialization; policy fingerprinting; hash-chained receipts; immutable dataclasses; strict repair monotonicity; no subprocess, network, shell, deployment, or cloud SDK calls; adversarial tests; explicit `NOT_CROSSED`.

## Residual risks
Semantic misclassification by adapters, forged upstream evidence/authority claims, inadequate organization-specific policy, compromised host runtime, weak key management outside this package, and unreviewed downstream executors.
