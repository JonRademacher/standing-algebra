from __future__ import annotations
from dataclasses import dataclass, asdict
from hashlib import sha256
import base64, hmac, json, time
from typing import Callable

def b64u(b:bytes)->str: return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
def unb64u(s:str)->bytes: return base64.urlsafe_b64decode(s+"="*((4-len(s)%4)%4))
def canonical(x)->bytes: return json.dumps(x,sort_keys=True,separators=(",",":")).encode()
@dataclass(frozen=True)
class Attestation:
    issuer:str; subject_digest:str; audience:str; purpose:str; issued_at:int; expires_at:int; nonce:str; key_id:str
class HMACTestSigner:
    """Reference signer for tests and air-gapped demos. Use KMS/HSM signing in production."""
    def __init__(self,key_id:str,key:bytes): self.key_id=key_id; self.key=key
    def sign(self,a:Attestation)->str:
        if a.key_id!=self.key_id: raise ValueError("key_id mismatch")
        body=b64u(canonical(asdict(a))); sig=b64u(hmac.new(self.key,body.encode(),sha256).digest())
        return body+"."+sig
class AttestationVerifier:
    def __init__(self,key_resolver:Callable[[str],bytes|None],issuer_allowlist:set[str],audience:str,clock:Callable[[],int]|None=None,max_ttl:int=900,skew:int=30):
        self.keys=key_resolver; self.issuers=issuer_allowlist; self.audience=audience; self.clock=clock or (lambda:int(time.time())); self.max_ttl=max_ttl; self.skew=skew
    def verify(self,token:str,subject_digest:str,purpose:str,nonce_seen:Callable[[str],bool])->tuple[bool,str]:
        try:
            body,sig=token.split('.',1); raw=json.loads(unb64u(body)); a=Attestation(**raw); key=self.keys(a.key_id)
            if key is None or not hmac.compare_digest(unb64u(sig),hmac.new(key,body.encode(),sha256).digest()): return False,"invalid signature"
            now=self.clock()
            if a.issuer not in self.issuers:return False,"untrusted issuer"
            if a.audience!=self.audience:return False,"audience mismatch"
            if a.subject_digest!=subject_digest:return False,"subject mismatch"
            if a.purpose!=purpose:return False,"purpose mismatch"
            if a.issued_at>now+self.skew or a.expires_at<now-self.skew:return False,"attestation outside validity window"
            if a.expires_at-a.issued_at>self.max_ttl:return False,"attestation ttl too long"
            if nonce_seen(a.nonce):return False,"replayed nonce"
            return True,a.nonce
        except Exception:return False,"malformed attestation"
