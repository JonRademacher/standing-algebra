from __future__ import annotations
from dataclasses import dataclass, replace
from hashlib import sha256
import hmac, json, threading
from .attestation import AttestationVerifier
from .engine import SigmaR, canonical
from .model import *
class MemoryNonceStore:
    def __init__(self): self._seen=set(); self._lock=threading.Lock()
    def contains(self,n):
        with self._lock:return n in self._seen
    def commit(self,n):
        with self._lock:
            if n in self._seen:return False
            self._seen.add(n);return True
@dataclass(frozen=True)
class RuntimeResult:
    inspection:Inspection; signed_receipt:str; sequence:int; previous_receipt_hash:str; execution_boundary:str=NOT_CROSSED
class HardenedRuntime:
    """Authenticated gate runtime. Still intentionally has no execution surface."""
    def __init__(self,engine:SigmaR,evidence:AttestationVerifier,authority:AttestationVerifier,receipt_key:bytes,nonce_store=None):
        self.engine=engine;self.evidence=evidence;self.authority=authority;self.key=receipt_key;self.nonces=nonce_store or MemoryNonceStore();self.seq=0;self.prev="GENESIS";self._lock=threading.Lock()
    def inspect(self,f:Finding,evidence_token:str,authority_token:str)->RuntimeResult:
        ok,en=self.evidence.verify(evidence_token,f.source_digest,"evidence",self.nonces.contains)
        if not ok: f=replace(f,evidence_refs=())
        ok2,an=self.authority.verify(authority_token,f.source_digest,"authority",self.nonces.contains)
        if not ok2: f=replace(f,authority_refs=())
        result=self.engine.inspect(f)
        if ok and ok2:
            if not self.nonces.commit(en) or not self.nonces.commit(an):
                f=replace(f,evidence_refs=());result=self.engine.inspect(f)
        with self._lock:
            self.seq+=1; payload={"sequence":self.seq,"previous":self.prev,"inspection":result,"execution_boundary":NOT_CROSSED}
            sig=hmac.new(self.key,canonical(payload),sha256).hexdigest(); signed=sha256(canonical(payload)+sig.encode()).hexdigest(); old=self.prev;self.prev=signed
            return RuntimeResult(result,sig,self.seq,old)
