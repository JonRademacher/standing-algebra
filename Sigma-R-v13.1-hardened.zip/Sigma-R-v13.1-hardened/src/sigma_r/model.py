from __future__ import annotations
from dataclasses import dataclass, asdict, replace
from enum import Enum
from typing import Any, Mapping

NOT_CROSSED = "NOT_CROSSED"
class Code(str, Enum):
    ALLOW="ALLOW"; ADAPTER_INCOMPLETE="ADAPTER_INCOMPLETE"; EVIDENCE_BLOCK="EVIDENCE_BLOCK"
    AUTHORITY_BLOCK="AUTHORITY_BLOCK"; PROTECTION_BLOCK="PROTECTION_BLOCK"; ADMISSIBILITY_BLOCK="ADMISSIBILITY_BLOCK"
class ResidualClass(str, Enum):
    NONE="NONE"; UNKNOWN="UNKNOWN"; MALFORMED="MALFORMED"
@dataclass(frozen=True)
class Proposal:
    engine:str; action:str; environment:str; scope:str
    risk:int=0; force:bool=False; auto_approve:bool=False; internet_exposure:bool=False
    authority_change:bool=False; protection_bypass:bool=False; dry_run:bool=False; plan_only:bool=False
@dataclass(frozen=True)
class Finding:
    schema_version:str; source_type:str; source_id:str; source_digest:str; proposal:Proposal
    evidence_refs:tuple[str,...]=(); authority_refs:tuple[str,...]=(); provenance:tuple[str,...]=()
    residuals:tuple[str,...]=(); residual_class:ResidualClass=ResidualClass.NONE; protected:bool=False
@dataclass(frozen=True)
class Decision:
    code:Code; reasons:tuple[str,...]; receipt_hash:str; policy_fingerprint:str
    execution_boundary:str=NOT_CROSSED
@dataclass(frozen=True)
class Inspection:
    root:Decision; candidates:tuple[Finding,...]; replay:tuple[Decision,...]; execution_boundary:str=NOT_CROSSED
