import argparse,json,sys
from dataclasses import asdict
from pathlib import Path
from .engine import SigmaR,Policy
from .model import Finding,Proposal,ResidualClass
def load_finding(d):
    d=dict(d); d["proposal"]=Proposal(**d["proposal"]); d["residual_class"]=ResidualClass(d.get("residual_class","NONE"))
    for k in ("evidence_refs","authority_refs","provenance","residuals"): d[k]=tuple(d.get(k,()))
    return Finding(**d)
def default(x): return x.value if hasattr(x,"value") else asdict(x) if hasattr(x,"__dataclass_fields__") else str(x)
def main():
    ap=argparse.ArgumentParser(prog="sigma-r"); ap.add_argument("command",choices=["inspect"]); ap.add_argument("file"); ap.add_argument("--max-risk",type=int,default=40)
    a=ap.parse_args(); raw=Path(a.file).read_bytes()
    if len(raw)>2_000_000: raise SystemExit("input exceeds 2 MB reference limit")
    f=load_finding(json.loads(raw)); result=SigmaR(Policy(max_risk=a.max_risk)).inspect(f)
    print(json.dumps(result,default=default,sort_keys=True,indent=2)); return 0 if result.root.code.value=="ALLOW" else 2
if __name__=="__main__": raise SystemExit(main())
