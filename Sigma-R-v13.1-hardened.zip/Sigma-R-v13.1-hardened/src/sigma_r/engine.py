from __future__ import annotations
from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json
from .model import *

def canonical(obj)->bytes:
    def default(x):
        if isinstance(x, Enum): return x.value
        if hasattr(x,'__dataclass_fields__'): return asdict(x)
        raise TypeError(type(x).__name__)
    return json.dumps(obj,sort_keys=True,separators=(",",":"),default=default).encode()
@dataclass(frozen=True)
class Policy:
    schema_version:str="sigma-r.finding/v1"; max_risk:int=40; max_input_bytes:int=2_000_000
    required_fields:tuple[str,...]=("engine","action","environment","scope")
    def fingerprint(self)->str: return sha256(canonical(asdict(self))).hexdigest()
class SigmaR:
    def __init__(self, policy:Policy|None=None): self.policy=policy or Policy()
    def _receipt(self,f:Finding,code:Code,reasons:tuple[str,...])->str:
        return sha256(canonical({"finding":f,"code":code.value,"reasons":reasons,"policy":self.policy.fingerprint(),"execution_boundary":NOT_CROSSED})).hexdigest()
    def _decision(self,f,code,reasons): return Decision(code,reasons,self._receipt(f,code,reasons),self.policy.fingerprint())
    def evaluate(self,f:Finding)->Decision:
        p=f.proposal; missing=[]
        if f.schema_version!=self.policy.schema_version: missing.append("unsupported:schema_version")
        for k in self.policy.required_fields:
            if not getattr(p,k,None): missing.append(f"missing:{k}")
        missing.extend(f.residuals)
        if f.residual_class==ResidualClass.MALFORMED or missing:
            return self._decision(f,Code.ADAPTER_INCOMPLETE,tuple(dict.fromkeys(missing or ("malformed adapter state",))))
        if f.residual_class==ResidualClass.UNKNOWN:
            return self._decision(f,Code.ADAPTER_INCOMPLETE,("unresolved epistemic residual",))
        if not f.evidence_refs: return self._decision(f,Code.EVIDENCE_BLOCK,("verifiable evidence reference missing",))
        if not f.authority_refs: return self._decision(f,Code.AUTHORITY_BLOCK,("verifiable authority reference missing",))
        if f.protected or p.protection_bypass or p.force:
            return self._decision(f,Code.PROTECTION_BLOCK,("protected condition cannot be internally repaired into permission",))
        hazards=[]
        if p.risk<0 or p.risk>100: hazards.append("risk outside 0..100")
        if p.risk>self.policy.max_risk: hazards.append(f"risk {p.risk} exceeds {self.policy.max_risk}")
        if p.environment=="production" and not (p.dry_run or p.plan_only): hazards.append("unbounded production mutation")
        if p.scope=="global" and not (p.dry_run or p.plan_only): hazards.append("unbounded global mutation")
        if p.internet_exposure: hazards.append("internet-wide exposure")
        if p.authority_change: hazards.append("authority mutation")
        if p.auto_approve: hazards.append("automatic approval")
        if hazards: return self._decision(f,Code.ADMISSIBILITY_BLOCK,tuple(hazards))
        return self._decision(f,Code.ALLOW,("complete, evidenced, authorized, protection-clear, within policy envelope",))
    def repair(self,f:Finding)->tuple[Finding,...]:
        d=self.evaluate(f)
        if d.code in {Code.ADAPTER_INCOMPLETE,Code.EVIDENCE_BLOCK,Code.AUTHORITY_BLOCK,Code.PROTECTION_BLOCK}: return ()
        p=f.proposal; out=[]
        def add(label, q): out.append(replace(f,source_id=f.source_id+"#repair:"+label,proposal=q,provenance=f.provenance+(label,)))
        if p.risk>self.policy.max_risk: add("bound-risk",replace(p,risk=self.policy.max_risk))
        if p.environment=="production": add("environment-to-canary",replace(p,environment="canary"))
        if p.scope=="global": add("scope-to-regional",replace(p,scope="regional"))
        if p.internet_exposure: add("remove-internet-exposure",replace(p,internet_exposure=False))
        if p.authority_change: add("remove-authority-change",replace(p,authority_change=False))
        if p.auto_approve: add("remove-auto-approve",replace(p,auto_approve=False))
        if p.action in {"apply","delete","destroy","patch","replace"} and not (p.dry_run or p.plan_only):
            add("non-mutating-preview",replace(p,dry_run=True,plan_only=p.engine=="terraform"))
        unique={canonical(x):x for x in out}
        return tuple(unique.values())
    def inspect(self,f:Finding)->Inspection:
        root=self.evaluate(f); candidates=self.repair(f); replay=tuple(self.evaluate(x) for x in candidates)
        return Inspection(root,candidates,replay)
