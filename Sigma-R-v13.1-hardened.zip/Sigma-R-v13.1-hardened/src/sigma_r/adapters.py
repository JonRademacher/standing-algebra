from __future__ import annotations
from hashlib import sha256
import json
from .model import *
def digest(obj): return sha256(json.dumps(obj,sort_keys=True,separators=(",",":")).encode()).hexdigest()
class TerraformPlanAdapter:
    def adapt(self,obj:dict,evidence_refs=(),authority_refs=()):
        out=[]
        for i,rc in enumerate(obj.get("resource_changes") or []):
            change=rc.get("change") or {}; actions=tuple(change.get("actions") or ())
            text=json.dumps(rc,sort_keys=True).lower(); residuals=() if actions else ("missing:change_actions",)
            action="destroy" if "delete" in actions else ("apply" if set(actions)&{"create","update"} else "plan")
            p=Proposal("terraform",action,"production" if "prod" in text else "staging","global" if "global" in text else "regional",risk=70 if action in {"destroy","apply"} else 10,internet_exposure="0.0.0.0/0" in text,authority_change="iam" in text or "role" in text)
            out.append(Finding("sigma-r.finding/v1","terraform",str(rc.get("address",i)),digest(rc),p,tuple(evidence_refs),tuple(authority_refs),(f"actions={actions}",),residuals,ResidualClass.MALFORMED if residuals else ResidualClass.NONE))
        return tuple(out)
class KubernetesObjectAdapter:
    def adapt(self,obj:dict,evidence_refs=(),authority_refs=()):
        kind=str(obj.get("kind") or ""); meta=obj.get("metadata") or {}; spec=obj.get("spec") or {}; text=json.dumps(obj,sort_keys=True).lower()
        residuals=() if kind else ("missing:kind",); privileged='"privileged": true' in text or '"hostnetwork": true' in text
        p=Proposal("kubernetes","apply","production" if "prod" in text else "staging","global" if kind.lower() in {"clusterrole","clusterrolebinding"} else "regional",risk=65,internet_exposure=str(spec.get("type","")).lower()=="loadbalancer",authority_change=kind.lower() in {"role","rolebinding","clusterrole","clusterrolebinding"},protection_bypass=privileged)
        sid=f"{kind or 'Unknown'}/{meta.get('namespace','default')}/{meta.get('name','unnamed')}"
        return (Finding("sigma-r.finding/v1","kubernetes",sid,digest(obj),p,tuple(evidence_refs),tuple(authority_refs),(f"kind={kind}",),residuals,ResidualClass.MALFORMED if residuals else ResidualClass.NONE,privileged),)
