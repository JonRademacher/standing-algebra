import unittest
from dataclasses import replace
from sigma_r import *
class Hardened(unittest.TestCase):
 def setUp(self):
  self.now=1700000000; self.key=b'x'*32; self.rkey=b'r'*32
  resolver=lambda kid:self.key if kid=='k1' else None
  self.ev=AttestationVerifier(resolver,{'issuer'},'sigma-r',clock=lambda:self.now)
  self.au=AttestationVerifier(resolver,{'issuer'},'sigma-r',clock=lambda:self.now)
  self.signer=HMACTestSigner('k1',self.key);self.rt=HardenedRuntime(SigmaR(),self.ev,self.au,self.rkey)
  p=Proposal('terraform','plan','canary','regional',10,plan_only=True)
  self.f=Finding('sigma-r.finding/v1','test','x','digest',p,('placeholder',),('placeholder',))
 def tok(self,purpose,nonce='n'):
  return self.signer.sign(Attestation('issuer','digest','sigma-r',purpose,self.now-1,self.now+60,nonce,'k1'))
 def test_valid_attestations_allow(self): self.assertEqual(self.rt.inspect(self.f,self.tok('evidence','e'),self.tok('authority','a')).inspection.root.code,Code.ALLOW)
 def test_tamper_blocks(self):
  t=self.tok('evidence','e'); t=t[:-1]+('A' if t[-1]!='A' else 'B')
  self.assertEqual(self.rt.inspect(self.f,t,self.tok('authority','a')).inspection.root.code,Code.EVIDENCE_BLOCK)
 def test_subject_binding(self):
  bad=self.signer.sign(Attestation('issuer','other','sigma-r','evidence',self.now-1,self.now+60,'e','k1'))
  self.assertEqual(self.rt.inspect(self.f,bad,self.tok('authority','a')).inspection.root.code,Code.EVIDENCE_BLOCK)
 def test_replay_blocks(self):
  e=self.tok('evidence','e');a=self.tok('authority','a')
  self.assertEqual(self.rt.inspect(self.f,e,a).inspection.root.code,Code.ALLOW)
  self.assertEqual(self.rt.inspect(self.f,e,a).inspection.root.code,Code.EVIDENCE_BLOCK)
 def test_expired_blocks(self):
  e=self.signer.sign(Attestation('issuer','digest','sigma-r','evidence',self.now-100,self.now-50,'e','k1'))
  self.assertEqual(self.rt.inspect(self.f,e,self.tok('authority','a')).inspection.root.code,Code.EVIDENCE_BLOCK)
 def test_receipt_chain(self):
  x=self.rt.inspect(self.f,self.tok('evidence','e1'),self.tok('authority','a1')); y=self.rt.inspect(self.f,self.tok('evidence','e2'),self.tok('authority','a2'))
  self.assertEqual(x.previous_receipt_hash,'GENESIS');self.assertNotEqual(y.previous_receipt_hash,'GENESIS');self.assertEqual(y.sequence,2)
 def test_runtime_has_no_executor(self): self.assertFalse(any(hasattr(self.rt,n) for n in ('execute','apply','deploy','send','run_command')))
if __name__=='__main__':unittest.main()
