import unittest
from sigma_r import *
class Adapters(unittest.TestCase):
 def test_missing_tf_actions(self):
  f=TerraformPlanAdapter().adapt({"resource_changes":[{"address":"x","change":{}}]})[0]
  self.assertEqual(SigmaR().evaluate(f).code,Code.ADAPTER_INCOMPLETE)
 def test_privileged_k8s_is_protected(self):
  obj={"apiVersion":"v1","kind":"Pod","metadata":{"name":"x"},"spec":{"containers":[{"securityContext":{"privileged":True}}]}}
  f=KubernetesObjectAdapter().adapt(obj,("e",),("a",))[0]
  self.assertEqual(SigmaR().evaluate(f).code,Code.PROTECTION_BLOCK)
if __name__=="__main__": unittest.main()
