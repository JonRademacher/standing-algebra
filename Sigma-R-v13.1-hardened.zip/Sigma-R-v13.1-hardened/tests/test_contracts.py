import unittest,random
from dataclasses import replace
from sigma_r import *
class Contracts(unittest.TestCase):
 def setUp(self):
  self.s=SigmaR(); self.p=Proposal("terraform","plan","canary","regional",10,plan_only=True)
  self.f=Finding("sigma-r.finding/v1","test","x","d",self.p,("e",),("a",))
 def test_allow(self): self.assertEqual(self.s.evaluate(self.f).code,Code.ALLOW)
 def test_gate_order(self):
  f=replace(self.f,residuals=("missing:x",),residual_class=ResidualClass.MALFORMED,evidence_refs=(),authority_refs=(),protected=True)
  self.assertEqual(self.s.evaluate(f).code,Code.ADAPTER_INCOMPLETE)
 def test_no_evidence(self): self.assertEqual(self.s.evaluate(replace(self.f,evidence_refs=())).code,Code.EVIDENCE_BLOCK)
 def test_no_authority(self): self.assertEqual(self.s.evaluate(replace(self.f,authority_refs=())).code,Code.AUTHORITY_BLOCK)
 def test_protection(self): self.assertEqual(self.s.evaluate(replace(self.f,protected=True)).code,Code.PROTECTION_BLOCK)
 def test_risk(self): self.assertEqual(self.s.evaluate(replace(self.f,proposal=replace(self.p,risk=41))).code,Code.ADMISSIBILITY_BLOCK)
 def test_repair_cannot_create_evidence_or_authority(self):
  for f in (replace(self.f,evidence_refs=()),replace(self.f,authority_refs=()),replace(self.f,protected=True)):
   self.assertEqual(self.s.repair(f),())
 def test_repair_preserves_prerequisites(self):
  f=replace(self.f,proposal=replace(self.p,risk=80,environment="production",scope="global",auto_approve=True))
  for c in self.s.repair(f):
   self.assertEqual(c.evidence_refs,f.evidence_refs); self.assertEqual(c.authority_refs,f.authority_refs); self.assertFalse(c.proposal.protection_bypass)
 def test_execution_boundary(self):
  z=self.s.inspect(self.f); self.assertEqual(z.execution_boundary,"NOT_CROSSED"); self.assertEqual(z.root.execution_boundary,"NOT_CROSSED")
 def test_no_executor_api(self):
  self.assertFalse(any(hasattr(self.s,n) for n in ("execute","apply","deploy","run_command","send")))
 def test_deterministic_receipt(self): self.assertEqual(self.s.evaluate(self.f).receipt_hash,self.s.evaluate(self.f).receipt_hash)
 def test_random_fail_closed(self):
  for _ in range(200):
   risk=random.randint(-20,130); f=replace(self.f,proposal=replace(self.p,risk=risk))
   d=self.s.evaluate(f); self.assertEqual(d.code==Code.ALLOW,0<=risk<=40)
if __name__=="__main__": unittest.main()
