# Production readiness status

## Implemented in v13.1
- Attestation signature, issuer, audience, purpose, subject-digest, TTL and clock-window verification
- Replay protection abstraction and atomic in-memory reference store
- Signed, sequence-linked receipt chain
- Fail-closed behavior for malformed, tampered, expired, mismatched, or replayed attestations
- Hardened Kubernetes deployment baseline
- Explicit non-execution API checks

## Required before a production designation
- Replace HMAC reference verification with organization-approved asymmetric KMS/HSM verification
- Replace in-memory nonce store with transactional Redis, PostgreSQL, or equivalent HA store
- Independent code/security review and remediation
- Dependency and container scans, SBOM, signed image, SLSA provenance
- Load, soak, fault-injection, restart, concurrency, and disaster-recovery tests
- Staging/canary integration against representative Terraform and Kubernetes artifacts
- Incident response, SLOs, dashboards, alerting, backup/restore, key rotation, and rollback drills
- Organization-specific policy approval and documented risk acceptance

The package is production-hardened but not self-certifying. Production readiness is environment- and organization-relative and requires the external gates above.
