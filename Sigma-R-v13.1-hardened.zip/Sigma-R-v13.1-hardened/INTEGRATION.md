# Integration Contract

1. Parse external artifacts in a sandboxed adapter.
2. Produce a `Finding` with source digest, provenance, explicit residual class, evidence references, authority references, and typed proposal.
3. Call `SigmaR.inspect`.
4. Persist the full response and receipt.
5. Permit downstream consideration only when decision is `ALLOW`, `execution_boundary` is `NOT_CROSSED`, the policy fingerprint matches the approved deployment policy, and external evidence/authority signatures independently verify.
6. A separate deployment controller performs any consequential action.

Recommended production additions: OIDC workload identity, signed in-toto/SLSA attestations, Sigstore verification, OPA or Cedar policy federation, KMS-backed receipt signing, OpenTelemetry, rate limiting, schema-version negotiation, and an audited human approval path for high-impact changes.
