# Security Policy

Report suspected vulnerabilities privately to the repository owner. Do not include live credentials, production payloads, or customer data.

Security boundaries:
- Sigma-R evaluates and proposes repairs; it does not execute.
- Boolean evidence and authority fields are integration claims, not self-authenticating proof. Production deployments must bind them to signed, verifiable records.
- Adapters are untrusted input boundaries. Unknown, malformed, or incomplete consequence-bearing fields fail closed.
- Receipt hashes provide tamper evidence inside a declared chain; they do not provide signer identity unless wrapped in an external signature system.
