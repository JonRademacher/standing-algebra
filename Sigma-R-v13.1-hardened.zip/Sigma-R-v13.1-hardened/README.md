# Sigma-R v13.1 Production Package

Sigma-R is a fail-closed, evidence- and authority-separated admissibility firewall for AI-generated infrastructure proposals. It converts adapter findings into typed consequence states, rejects incomplete or ungrounded input, and can generate bounded repair candidates without executing them.

## Hard invariant

`proposal != evidence != adapter completeness != admissibility != authority != execution`

This package intentionally exposes **no executor**. Every decision and replay result reports `execution_boundary: NOT_CROSSED`. An integrating company must place its own separately authorized deployment system downstream.

## Included

- Typed decision model and policy engine
- Fail-closed completeness gate
- Evidence and authority gates
- Protection and risk-envelope gates
- Terraform-plan JSON and Kubernetes-object adapters
- Dimension-local repair/replay with immutable evidence, authority, and protection fields
- Hash-chained receipts and deterministic canonical JSON
- JSON Schema for findings
- CLI for JSON/JSONL inspection
- Unit, adversarial, property-style, and execution-boundary tests
- Dockerfile, CI workflow, SBOM-generation instructions, threat model, and integration guide

## Quick start

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .
python -m unittest discover -s tests -v
sigma-r inspect examples/finding-safe.json
```

## Decision order

1. `ADAPTER_INCOMPLETE`
2. `EVIDENCE_BLOCK`
3. `AUTHORITY_BLOCK`
4. `PROTECTION_BLOCK`
5. `ADMISSIBILITY_BLOCK`
6. `ALLOW`

No later gate can repair an earlier missing prerequisite into permission. `ALLOW` means only that the supplied finding survived this policy evaluation. It never means execution occurred or is generally authorized.

## Production integration

Run Sigma-R as a stateless pre-execution policy service. Preserve the returned receipt, policy version, source artifact digest, adapter provenance, decision, residuals, and execution boundary. Require a separate deployment controller to verify the receipt and enforce organization-specific approvals.

## Validation status

The included suite verifies internal contracts in this package. It is not independent certification, a security audit, or proof of fitness for a particular production environment.


## v13.1 hardening
See `PRODUCTION_READINESS.md`. This release adds authenticated attestation verification, replay defense, signed receipt chaining, and a hardened Kubernetes baseline.
