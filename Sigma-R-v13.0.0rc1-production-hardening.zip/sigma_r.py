from __future__ import annotations
from dataclasses import dataclass, asdict, replace
from enum import Enum
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping
import json, os, tempfile, time, uuid

class Code(str, Enum):
    ALLOW='ALLOW'; EVIDENCE_BLOCK='EVIDENCE_BLOCK'; AUTHORITY_BLOCK='AUTHORITY_BLOCK'; PROTECTION_BLOCK='PROTECTION_BLOCK'; RISK_BLOCK='RISK_BLOCK'; ADAPTER_INCOMPLETE='ADAPTER_INCOMPLETE'; PARTIAL_UNKNOWN='PARTIAL_UNKNOWN'

@dataclass(frozen=True)
class Evidence:
    source: str
    observed_ns: int
    digest: str
    valid: bool=True

@dataclass(frozen=True)
class Authority:
    principal: str
    scope: tuple[str,...]
    expires_ns: int
    token_digest: str
    valid: bool=True

@dataclass(frozen=True)
class Proposal:
    engine: str
    action: str
    environment: str
    scope: str
    payload_digest: str
    evidence: Evidence|None=None
    authority: Authority|None=None
    force: bool=False
    internet_exposure: bool=False
    authority_change: bool=False
    protection_bypass: bool=False
    dry_run: bool=False
    plan_only: bool=False
    residuals: tuple[str,...]=()
    residual_class: str='NONE'

@dataclass(frozen=True)
class Decision:
    code: Code
    risk: int
    hazards: tuple[str,...]
    reasons: tuple[str,...]
    proposal_digest: str
    policy_version: str

@dataclass(frozen=True)
class Policy:
    version: str='13.0.0-prod-candidate'
    max_risk: int=40
    evidence_ttl_s: int=900
    require_receipts: bool=True

class Firewall:
    WEIGHTS={'force':55,'mutation':40,'global_scope':45,'production_scope':25,'internet_scope':35,'authority_mutation':35,'protection_bypass':100}
    def __init__(self, policy:Policy=Policy()): self.policy=policy
    def hazards(self,p:Proposal)->tuple[str,...]:
        h=[]
        if p.force:h.append('force')
        if p.action in {'delete','destroy','apply','patch','replace'} and not (p.dry_run or p.plan_only):h.append('mutation')
        if p.scope=='global':h.append('global_scope')
        if p.environment=='production':h.append('production_scope')
        if p.internet_exposure:h.append('internet_scope')
        if p.authority_change:h.append('authority_mutation')
        if p.protection_bypass:h.append('protection_bypass')
        return tuple(h)
    def evaluate(self,p:Proposal,now_ns:int|None=None)->Decision:
        now_ns=now_ns or time.time_ns(); hz=self.hazards(p); risk=min(100,sum(self.WEIGHTS[x] for x in hz)); why=[]
        dig=sha256(canonical(asdict(p))).hexdigest()
        if p.residuals:
            code=Code.PARTIAL_UNKNOWN if p.residual_class.upper()=='UNKNOWN' else Code.ADAPTER_INCOMPLETE
            return Decision(code,risk,hz,tuple(p.residuals),dig,self.policy.version)
        if not p.evidence or not p.evidence.valid or now_ns-p.evidence.observed_ns>self.policy.evidence_ttl_s*1_000_000_000:
            return Decision(Code.EVIDENCE_BLOCK,risk,hz,('fresh independent evidence required',),dig,self.policy.version)
        a=p.authority
        required={p.engine,p.environment,p.scope,p.action}
        if not a or not a.valid or a.expires_ns<now_ns or not required.issubset(set(a.scope)):
            return Decision(Code.AUTHORITY_BLOCK,risk,hz,('valid scoped unexpired authority required',),dig,self.policy.version)
        if p.protection_bypass or p.force:
            return Decision(Code.PROTECTION_BLOCK,risk,hz,('protection bypass is non-repairable at this gate',),dig,self.policy.version)
        if risk>self.policy.max_risk:
            return Decision(Code.RISK_BLOCK,risk,hz,(f'risk {risk} exceeds {self.policy.max_risk}',),dig,self.policy.version)
        return Decision(Code.ALLOW,risk,hz,(),dig,self.policy.version)

def canonical(obj:Any)->bytes:
    return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,default=str).encode('utf-8')

class ReceiptStore:
    def __init__(self,path:str|Path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.previous=self._recover()
    def _recover(self)->str:
        if not self.path.exists():return '0'*64
        prev='0'*64
        for n,line in enumerate(self.path.read_text('utf-8').splitlines(),1):
            rec=json.loads(line); claimed=rec.pop('receipt_hash');
            if rec.get('previous_receipt_hash')!=prev or sha256(canonical(rec)).hexdigest()!=claimed: raise RuntimeError(f'receipt chain corrupt at line {n}')
            prev=claimed
        return prev
    def append(self,proposal:Proposal,decision:Decision)->Mapping[str,Any]:
        body={'schema':'sigma-r.receipt/v1','receipt_id':str(uuid.uuid4()),'timestamp_ns':time.time_ns(),'proposal':asdict(proposal),'decision':asdict(decision),'previous_receipt_hash':self.previous}
        body['receipt_hash']=sha256(canonical(body)).hexdigest(); line=canonical(body)+b'\n'
        fd,tmp=tempfile.mkstemp(prefix='.sigma-r-',dir=str(self.path.parent)); os.close(fd)
        try:
            with open(tmp,'wb') as out:
                if self.path.exists(): out.write(self.path.read_bytes())
                out.write(line); out.flush(); os.fsync(out.fileno())
            os.replace(tmp,self.path)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)
        self.previous=body['receipt_hash']; return body

class RepairReplay:
    """Candidate-only repair. Never manufactures evidence/authority and never executes."""
    def __init__(self,fw:Firewall,max_states:int=256): self.fw=fw; self.max_states=max_states
    def transforms(self,p:Proposal):
        out=[]
        if p.force: out.append(('remove-force',replace(p,force=False)))
        if p.action in {'destroy','apply'} and not p.plan_only: out.append(('plan-only',replace(p,plan_only=True)))
        if p.action in {'delete','apply','patch','replace'} and not p.dry_run: out.append(('dry-run',replace(p,dry_run=True)))
        if p.internet_exposure: out.append(('narrow-network',replace(p,internet_exposure=False)))
        if p.scope=='global': out.append(('scope-regional',replace(p,scope='regional')))
        if p.environment=='production': out.append(('environment-canary',replace(p,environment='canary')))
        if p.authority_change: out.append(('remove-authority-change',replace(p,authority_change=False)))
        return out
    def run(self,p:Proposal)->dict[str,Any]:
        q=[(('root',),p)]; seen={sha256(canonical(asdict(p))).hexdigest()}; nodes=[]
        while q and len(nodes)<self.max_states:
            lineage,cur=q.pop(0); d=self.fw.evaluate(cur); nodes.append((lineage,cur,d))
            if cur.residuals: continue
            before=set(self.fw.hazards(cur))
            for name,nxt in self.transforms(cur):
                if nxt.evidence!=cur.evidence or nxt.authority!=cur.authority or nxt.protection_bypass!=cur.protection_bypass: continue
                if not set(self.fw.hazards(nxt)) < before: continue
                k=sha256(canonical(asdict(nxt))).hexdigest()
                if k not in seen:seen.add(k);q.append((lineage+(name,),nxt))
        return {'execution_boundary':'NOT_CROSSED','truncated':bool(q),'nodes':nodes,'survivors':[n for n in nodes if n[2].code==Code.ALLOW]}
