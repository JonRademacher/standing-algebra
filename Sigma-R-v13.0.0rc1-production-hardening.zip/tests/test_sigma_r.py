import time
from sigma_r import *

def good(**kw):
 n=time.time_ns(); e=Evidence('canary',n,'e'*64); a=Authority('ops',('terraform','canary','regional','plan'),n+10**12,'a'*64); return Proposal('terraform','plan','canary','regional','p'*64,e,a,**kw)
def test_allow(): assert Firewall().evaluate(good()).code==Code.ALLOW
def test_no_evidence(): assert Firewall().evaluate(replace(good(),evidence=None)).code==Code.EVIDENCE_BLOCK
def test_scope_authority(): assert Firewall().evaluate(replace(good(),environment='production')).code==Code.AUTHORITY_BLOCK
def test_force_block(): assert Firewall().evaluate(good(force=True)).code==Code.PROTECTION_BLOCK
def test_unknown_not_allow(): assert Firewall().evaluate(good(residuals=('x',),residual_class='UNKNOWN')).code==Code.PARTIAL_UNKNOWN
def test_repair_never_executes(): assert RepairReplay(Firewall()).run(good())['execution_boundary']=='NOT_CROSSED'
def test_receipt_tamper(tmp_path):
 s=ReceiptStore(tmp_path/'a.jsonl'); p=good(); s.append(p,Firewall().evaluate(p)); x=tmp_path/'a.jsonl'; x.write_text(x.read_text().replace('ALLOW','NOPE'))
 try: ReceiptStore(x); assert False
 except RuntimeError: pass
