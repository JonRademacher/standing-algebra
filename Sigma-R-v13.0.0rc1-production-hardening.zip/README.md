# Sigma-R production-hardening candidate v13.0.0rc1

Fail-closed admissibility boundary for consequential agent proposals. This package deliberately contains **no executor**.

## v12.1 -> v13 hardening
- typed evidence and scoped authority with freshness/expiry
- canonical proposal digest and versioned decisions
- fail-closed malformed/UNKNOWN residual handling
- append-only hash-chained JSONL receipts with startup verification and atomic replacement
- candidate-only structured Repair/Replay; evidence, authority and protection bypass cannot be manufactured
- bounded replay state space and explicit truncation
- zero runtime dependencies

## Production deployment requirements
Run the gate in a separate least-privilege service/process; authenticate evidence and authority issuers; store receipts on durable append-only/WORM-capable storage; pin and sign builds; enforce rate/size limits before deserialization; monitor BLOCK and receipt-write failures; fail closed if auditing is required but unavailable; fuzz adapters and parsers; penetration-test separation from executors; run crash/restart/concurrency testing.

## Test
`python -m pytest -q`

## Status
Release candidate. Passing unit tests establishes internal executable verification only, not independent production validation, penetration testing, or certification.
